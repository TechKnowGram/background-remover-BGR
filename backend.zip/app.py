from flask import Flask, request, jsonify, send_from_directory, send_file
from werkzeug.utils import secure_filename
from flask_cors import CORS
import os
import uuid
import zipfile
import cv2
from PIL import Image
import numpy as np
import torch
import torchvision.models as models
from torchvision.models.mobilenetv2 import MobileNetV2, MobileNet_V2_Weights
from pathlib import Path
import sys
import logging
import shutil
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from sqlalchemy.exc import IntegrityError
from functools import wraps

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Flask application setup
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/your_database_name'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'your_jwt_secret_key'

# Download MobileNetV2 weights first - do this before trying to use MODNet
logger.info("Downloading MobileNetV2 weights...")
_ = models.mobilenet_v2(weights=MobileNet_V2_Weights.IMAGENET1K_V1)

# Identify where PyTorch stores pre-trained models
torch_home = os.path.expanduser(os.getenv('TORCH_HOME', '~/.torch'))
model_dir = os.path.join(torch_home, 'checkpoints')

# Print for debugging
logger.info(f"PyTorch model directory: {model_dir}")
logger.info(f"Files in directory: {os.listdir(model_dir) if os.path.exists(model_dir) else 'Directory not found'}")

# Configure MODNet path - update these paths to your actual installation
base_dir = os.path.dirname(os.path.abspath(__file__))
modnet_dir = os.path.join(base_dir, "MODNet")
modnet_src_dir = os.path.join(modnet_dir, "src")

# Add MODNet to the Python path
if modnet_src_dir not in sys.path:
    sys.path.append(modnet_src_dir)

# Add model directories to Python path
modnet_models_dir = os.path.join(modnet_src_dir, "models")
modnet_backbones_dir = os.path.join(modnet_src_dir, "backbones")

if modnet_models_dir not in sys.path:
    sys.path.append(modnet_models_dir)
if modnet_backbones_dir not in sys.path:
    sys.path.append(modnet_backbones_dir)

# Import MODNet modules - using a more robust approach for relative imports
try:
    # First, make the MODNet directory a package by creating __init__.py files
    modnet_init_file = os.path.join(modnet_dir, "__init__.py")
    if not os.path.exists(modnet_init_file):
        with open(modnet_init_file, 'w') as f:
            pass  # Create an empty file
            
    src_init_file = os.path.join(modnet_src_dir, "__init__.py")
    if not os.path.exists(src_init_file):
        with open(src_init_file, 'w') as f:
            pass
            
    models_init_file = os.path.join(modnet_src_dir, "models", "__init__.py")
    if not os.path.exists(models_init_file):
        with open(models_init_file, 'w') as f:
            pass
            
    backbones_init_file = os.path.join(modnet_src_dir, "backbones", "__init__.py")
    if not os.path.exists(backbones_init_file):
        with open(backbones_init_file, 'w') as f:
            pass
    
    # Add the parent directory to sys.path
    parent_dir = os.path.dirname(base_dir)
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)
    
    # Now try to import using the package structure
    from MODNet.src.models.modnet import MODNet
    logger.info("Successfully imported MODNet model")
except Exception as e:
    logger.error(f"Failed to import MODNet: {str(e)}")
    logger.error("Please ensure MODNet is correctly installed")
    logger.error(f"Python path: {sys.path}")
    
    # As a fallback, try a direct approach without relying on imports
    try:
        # Get the content of modnet.py
        modnet_file = os.path.join(modnet_src_dir, "models", "modnet.py")
        
        if os.path.exists(modnet_file):
            # Create a custom namespace to execute the file
            namespace = {
                "__file__": modnet_file,
                "__name__": "__main__",
                "torch": torch,  # Provide required dependencies
                "nn": torch.nn,
                "F": torch.nn.functional
            }
            
            # Read the file content
            with open(modnet_file, 'r') as f:
                modnet_code = f.read()
                
            # Modify imports if needed (handle relative imports)
            modnet_code = modnet_code.replace("from ..backbones", "from BGR.backend.MODNet.src.backbones")
            
            # Execute in the namespace
            exec(modnet_code, namespace)
            
            # Extract the MODNet class
            if 'MODNet' in namespace:
                MODNet = namespace['MODNet']
                logger.info("Successfully loaded MODNet using exec approach")
            else:
                logger.error("MODNet class not found in the module")
        else:
            logger.error(f"MODNet file not found at: {modnet_file}")
    except Exception as e:
        logger.error(f"Failed to load MODNet using exec approach: {str(e)}")

# NOW you can create the MODNet model instance AFTER it's been imported
# Initialize to None first
modnet_model = None
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Flask extensions
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)

# Configuration
app.config['UPLOAD_FOLDER'] = 'static/uploads/'
app.config['PROCESSED_FOLDER'] = 'static/processed/'
app.config['FRAMES_FOLDER'] = 'static/frames/'
app.config['PROCESSED_ZIP_FOLDER'] = 'static/processed_zips/'
app.config['VIDEOS_FOLDER'] = 'static/videos/'
app.config['BACKGROUND_FRAMES_FOLDER'] = 'static/background_frames/'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif', 'mp4', 'avi', 'mov'}
app.secret_key = 'super_secret_key'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB limit

# Create necessary directories
for folder in [
    app.config['UPLOAD_FOLDER'],
    app.config['PROCESSED_FOLDER'],
    app.config['FRAMES_FOLDER'],
    app.config['PROCESSED_ZIP_FOLDER'],
    app.config['VIDEOS_FOLDER'],
    app.config['BACKGROUND_FRAMES_FOLDER']
]:
    if not os.path.exists(folder):
        os.makedirs(folder)

# Global variables to store processed items
processed_images = []
extracted_frames = []
background_frames = []

def load_modnet_model():
    """Load the MODNet model properly with error handling."""
    global modnet_model
    try:
        # Define the correct model path
        base_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(base_dir, 'models/modnet_photographic_portrait_matting.ckpt')

        if not os.path.exists(model_path):
            logger.error(f"Model file not found at: {model_path}")
            return False

        # Initialize MODNet model
        modnet_model = MODNet(backbone_pretrained=False)

        # Load model state dictionary properly
        state_dict = torch.load(model_path, map_location=device)

        # Remove 'module.' prefix if model was trained using DataParallel
        new_state_dict = {k.replace('module.', ''): v for k, v in state_dict.items()}
        
        modnet_model.load_state_dict(new_state_dict, strict=False)

        # Set model to evaluation mode and move to device
        modnet_model.eval()
        modnet_model.to(device)

        logger.info(f"MODNet model loaded successfully using {device}")
        return True
    except Exception as e:
        logger.error(f"Failed to load MODNet model: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return False

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    fullname = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(50), default='general')

    def __repr__(self):
        return f'<User {self.fullname}>'

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password, password)

# Initialize the database
with app.app_context():
    db.create_all()

# Utility functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Role-based access control decorator
def role_required(role):
    def decorator(fn):
        @wraps(fn)
        @jwt_required()
        def wrapper(*args, **kwargs):
            current_user = get_jwt_identity()
            if current_user['role'] != role:
                return jsonify({'message': f'Access restricted to {role} users'}), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator

def remove_background_modnet(image_path, output_path, background_frames=None, background_color=None):
    """Process an image with MODNet to remove its background."""
    try:
        global modnet_model
        if modnet_model is None:
            success = load_modnet_model()
            if not success:
                logger.error("Failed to load MODNet model")
                return False
        
        # Ensure model is on the correct device
        modnet_model = modnet_model.to(device) 
                
        # Ensure input file exists
        if not os.path.exists(image_path):
            logger.error(f"Input file does not exist: {image_path}")
            return False
            
        # Load and preprocess input image
        try:
            input_image = Image.open(image_path).convert("RGB")
        except Exception as e:
            logger.error(f"Failed to open image {image_path}: {str(e)}")
            return False
            
        orig_width, orig_height = input_image.size
        
        # Preprocess for MODNet - normalize to [0, 1] and convert to tensor
        input_tensor = np.array(input_image) / 255.0
        input_tensor = torch.from_numpy(input_tensor.transpose(2, 0, 1)).float().unsqueeze(0).to(device)
        
        # Resize if needed - MODNet works best with 512x512
        if orig_width > 512 or orig_height > 512:
            input_tensor = torch.nn.functional.interpolate(input_tensor, size=(512, 512), mode='bilinear', align_corners=False)
        
        # Run MODNet inference
        with torch.no_grad():
            _, _, matte = modnet_model(input_tensor, True)
        
        # Process matte
        matte = matte[0][0].cpu().numpy()
        
        # Resize matte back to original dimensions
        matte = cv2.resize(matte, (orig_width, orig_height), interpolation=cv2.INTER_LINEAR)
        
        # IMPORTANT: Changed threshold and removed any artistic filtering
        # Make background completely transparent with a more aggressive threshold
        matte[matte < 0.5] = 0  # Increased threshold for more aggressive background removal
        
        # IMPORTANT: Added post-processing to improve mask quality
        # Apply binary thresholding to create a cleaner mask
        _, binary_mask = cv2.threshold(matte, 0.1, 1.0, cv2.THRESH_BINARY)
        
        # Optional: Apply morphological operations to clean up the mask
        kernel = np.ones((5,5), np.uint8)
        binary_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_OPEN, kernel)
        binary_mask = cv2.morphologyEx(binary_mask, cv2.MORPH_CLOSE, kernel)
        
        # Use the cleaned binary mask
        matte = binary_mask
        
        # Scale to 0-255 for alpha channel
        matte = (matte * 255).astype(np.uint8)
        
        # Create foreground with alpha channel
        foreground_rgb = np.array(input_image)
        alpha_channel = np.expand_dims(matte, axis=2)
        foreground_rgba = np.concatenate((foreground_rgb, alpha_channel), axis=2)
        
        # Create foreground PIL image with alpha
        foreground_img = Image.fromarray(foreground_rgba, 'RGBA')
        
        # Prepare background
        if background_color == 'transparent' or background_color is None:
            # For transparent background, just save the foreground with alpha
            result = foreground_img
            logger.info("Using transparent background")
        else:
            # For colored background or image background
            if background_frames and len(background_frames) > 0:
                # Use background image
                bg_frame = np.random.choice(background_frames)
                bg_path = os.path.join(app.config['BACKGROUND_FRAMES_FOLDER'], bg_frame)
                background = Image.open(bg_path).convert("RGBA").resize((orig_width, orig_height), Image.LANCZOS)
            else:
                # Use color background
                try:
                    if background_color.startswith('#'):
                        r = int(background_color[1:3], 16)
                        g = int(background_color[3:5], 16)
                        b = int(background_color[5:7], 16)
                        background = Image.new("RGBA", (orig_width, orig_height), (r, g, b, 255))
                    elif ',' in background_color:
                        r, g, b = map(int, background_color.split(','))
                        background = Image.new("RGBA", (orig_width, orig_height), (r, g, b, 255))
                    else:
                        background = Image.new("RGBA", (orig_width, orig_height), background_color)
                except:
                    background = Image.new("RGBA", (orig_width, orig_height), (0, 0, 0, 0))
            
            # Composite the foreground over the background
            result = Image.alpha_composite(background.convert("RGBA"), foreground_img)
        
        # IMPORTANT: Save as PNG to preserve transparency
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        if not output_path.lower().endswith('.png'):
            output_path = output_path.rsplit('.', 1)[0] + '.png'
        result.save(output_path, 'PNG')
        
        return True
    except Exception as e:
        logger.error(f"Error in remove_background_modnet: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return False

# Process image function (main handler)
def process_image_with_background(image_path, output_path, background_frames=None, background_color='transparent'):
    """Process image using MODNet only."""
    logger.info("Using MODNet for background removal")
    return remove_background_modnet(image_path, output_path, background_frames, background_color)
    
# Video processing functions
def extract_frames_from_video(video_path, output_folder):
    """Extract frames from a video file with improved error handling."""
    try:
        if not os.path.exists(video_path):
            logger.error(f"Video file not found: {video_path}")
            return []
            
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            logger.error(f"Could not open video file: {video_path}")
            return []
        
        # Get video properties
        fps = int(cap.get(cv2.CAP_PROP_FPS))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        # Calculate frame extraction interval
        frame_interval = max(1, int(fps / 30))  # Cap at 30fps
        
        frame_count = 0
        extracted_frame_paths = []
        
        os.makedirs(output_folder, exist_ok=True)
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
                
            # Only process frames at the specified interval
            if frame_count % frame_interval == 0:
                # Enhance frame quality
                frame = cv2.bilateralFilter(frame, 9, 75, 75)  # Reduce noise while preserving edges
                
                frame_filename = f"frame_{uuid.uuid4()}.png"
                frame_path = os.path.join(output_folder, frame_filename)
                
                # Save frame with high quality
                cv2.imwrite(frame_path, frame, [cv2.IMWRITE_PNG_COMPRESSION, 0])
                extracted_frame_paths.append(frame_filename)
            
            frame_count += 1
            
        cap.release()
        return extracted_frame_paths
    except Exception as e:
        logger.error(f"Error extracting frames from video: {str(e)}")
        return []

def create_video_from_frames(frames, output_video_path, frame_rate=30):
    """Create a video from a sequence of frames with improved error handling."""
    try:
        if not frames:
            logger.error("No frames provided for video creation")
            return False

        frame_paths = [os.path.join(app.config['FRAMES_FOLDER'], frame) for frame in frames]
        
        # Check if first frame exists
        if not os.path.exists(frame_paths[0]):
            logger.error(f"First frame not found: {frame_paths[0]}")
            return False
            
        first_frame = cv2.imread(frame_paths[0])
        
        if first_frame is None:
            logger.error("Could not read first frame")
            return False

        height, width, layers = first_frame.shape

        # Create output directory if it doesn't exist
        os.makedirs(os.path.dirname(output_video_path), exist_ok=True)

        # Use better video codec and settings
        fourcc = cv2.VideoWriter_fourcc(*'avc1')  # H.264 codec
        video_writer = cv2.VideoWriter(
            output_video_path,
            fourcc,
            frame_rate,
            (width, height),
            True
        )

        for frame_path in frame_paths:
            if not os.path.exists(frame_path):
                logger.warning(f"Frame not found: {frame_path}")
                continue
                
            frame = cv2.imread(frame_path)
            if frame is not None:
                # Apply any final frame enhancements here if needed
                video_writer.write(frame)
            else:
                logger.warning(f"Could not read frame: {frame_path}")

        video_writer.release()
        logger.info(f"Video created successfully: {output_video_path}")
        return True
    except Exception as e:
        logger.error(f"Error creating video from frames: {str(e)}")
        return False

def remove_background_from_frames(frames, background_frames, background_color=None):
    """Process multiple frames to remove backgrounds using MODNet."""
    processed_frames = []
    total_frames = len(frames)
    
    # Log total frames to be processed
    logger.info(f"Processing {total_frames} frames with background removal")
    
    for i, frame in enumerate(frames):
        frame_path = os.path.join(app.config['FRAMES_FOLDER'], frame)
        processed_frame_path = os.path.join(app.config['FRAMES_FOLDER'], f"processed_{frame}")
        
        # Log progress
        if i % 10 == 0:  # Log every 10 frames
            logger.info(f"Processing frame {i+1}/{total_frames} ({(i+1)/total_frames*100:.1f}%)")
            
        try:
            success = remove_background_modnet(frame_path, processed_frame_path, background_frames, background_color)
            if success:
                processed_frames.append(f"processed_{frame}")
            else:
                logger.error(f"Failed to process frame: {frame}")
                # Fall back to original frame if processing fails
                shutil.copy(frame_path, processed_frame_path)
                processed_frames.append(f"processed_{frame}")
        except Exception as e:
            logger.error(f"Error processing frame {frame_path}: {str(e)}")
            # Fall back to original frame if processing fails
            shutil.copy(frame_path, processed_frame_path)
            processed_frames.append(f"processed_{frame}")
    
    logger.info(f"Successfully processed {len(processed_frames)} out of {total_frames} frames")
    return processed_frames


# API Routes
@app.route('/api/process_image', methods=['POST'])
def process_single_image():
    """API endpoint to process a single image."""
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image uploaded'}), 400
        
        file = request.files['image']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
            
        if not allowed_file(file.filename):
            return jsonify({'error': 'File type not allowed'}), 400
        
        filename = secure_filename(file.filename)
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        output_path = os.path.join(app.config['PROCESSED_FOLDER'], f"processed_{filename}")

        # Save the uploaded file
        os.makedirs(os.path.dirname(input_path), exist_ok=True)
        file.save(input_path)

        # Ensure the model is loaded
        if modnet_model is None:
            success = load_modnet_model()
            if not success:
                return jsonify({'error': 'Failed to load image processing model'}), 500

        # Process the image
        success = process_image_with_background(input_path, output_path)
        if not success:
            return jsonify({'error': 'Image processing failed'}), 500
        
        # Return the processed image path
        output_url = f"/static/processed/processed_{filename}"
        return jsonify({'message': 'Image processed successfully', 'output_path': output_url}), 200
    except Exception as e:
        logger.error(f"Error in process_single_image: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/process', methods=['POST'])
def process_multiple_files():
    """Process multiple files (images and videos)."""
    try:
        # Check if files were uploaded
        if 'files[]' not in request.files:
            return jsonify({'error': 'No files uploaded'}), 400
            
        files = request.files.getlist('files[]')
        background_image = request.files.get('background_image')
        background_video = request.files.get('background_video')
        background_color = request.form.get('background_color', None)

        # Reset tracking lists
        global processed_images, extracted_frames, background_frames
        processed_images = []
        extracted_frames = []
        background_frames = []

        # Ensure model is loaded
        if modnet_model is None:
            success = load_modnet_model()
            if not success:
                return jsonify({'error': 'Failed to load image processing model'}), 500

        # Process background image (if provided)
        if background_image and background_image.filename and allowed_file(background_image.filename):
            bg_filename = secure_filename(background_image.filename)
            bg_path = os.path.join(app.config['BACKGROUND_FRAMES_FOLDER'], bg_filename)
            os.makedirs(os.path.dirname(bg_path), exist_ok=True)
            background_image.save(bg_path)
            background_frames.append(bg_filename)
            logger.info(f"Background image saved: {bg_filename}")

        # Process background video (if provided)
        if background_video and background_video.filename and allowed_file(background_video.filename):
            bg_video_filename = secure_filename(background_video.filename)
            bg_video_path = os.path.join(app.config['VIDEOS_FOLDER'], bg_video_filename)
            os.makedirs(os.path.dirname(bg_video_path), exist_ok=True)
            background_video.save(bg_video_path)
            bg_frames = extract_frames_from_video(bg_video_path, app.config['BACKGROUND_FRAMES_FOLDER'])
            background_frames.extend(bg_frames)
            logger.info(f"Background video processed: {bg_video_filename}, extracted {len(bg_frames)} frames")

        # Set default background color if not specified and no background frames
        if not background_frames and (background_color is None or background_color == ''):
            background_color = 'transparent'
            logger.info("Using default transparent background")
        else:
            logger.info(f"Using background color: {background_color}")

        # Check if we have any files to process
        if len(files) == 0:
            return jsonify({'error': 'No valid files provided'}), 400

        # Process each uploaded file
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                file.save(file_path)
                logger.info(f"Processing file: {filename}")

                file_ext = filename.rsplit('.', 1)[1].lower()

                # Process images
                if file_ext in {'png', 'jpg', 'jpeg', 'gif'}:
                    processed_filename = f"processed_{filename.rsplit('.', 1)[0]}.png"
                    processed_file_path = os.path.join(app.config['PROCESSED_FOLDER'], processed_filename)

                    # Debug information
                    logger.info(f"Background frames: {background_frames}")
                    logger.info(f"Background color: {background_color}")
                    
                    # Apply MODNet for background removal
                    success = remove_background_modnet(
                        file_path, 
                        processed_file_path, 
                        background_frames, 
                        background_color
                    )
                    
                    if success:
                        processed_images.append(processed_filename)
                        logger.info(f"Successfully processed image: {processed_filename}")
                    else:
                        logger.error(f"Failed to process image: {filename}")
                        return jsonify({'error': f'Failed to process image: {filename}'}), 500

                # Process videos
                elif file_ext in {'mp4', 'avi', 'mov'}:
                    # Extract frames from video
                    frame_list = extract_frames_from_video(file_path, app.config['FRAMES_FOLDER'])
                    extracted_frames.extend(frame_list)
                    
                    if not frame_list:
                        return jsonify({'error': f'Failed to extract frames from video: {filename}'}), 500
                    
                    # Process each frame
                    processed_frames = remove_background_from_frames(frame_list, background_frames, background_color)
                    
                    if not processed_frames:
                        return jsonify({'error': f'Failed to process video frames: {filename}'}), 500
                    
                    # Create processed video
                    processed_video_filename = f"processed_{filename.rsplit('.', 1)[0]}.mp4"
                    processed_video_path = os.path.join(app.config['VIDEOS_FOLDER'], processed_video_filename)
                    
                    success = create_video_from_frames(processed_frames, processed_video_path)
                    if success:
                        video_url = f"/static/videos/{processed_video_filename}"
                        return jsonify({
                            'message': 'Video processed successfully',
                            'processed_images': processed_images,
                            'processed_video': video_url
                        })
                    else:
                        return jsonify({'error': f'Failed to create processed video: {filename}'}), 500

        # Return processed image URLs
        image_urls = [f"/static/processed/{img}" for img in processed_images]
        return jsonify({
            'message': 'Files processed successfully',
            'processed_images': image_urls,
            'extracted_frames': extracted_frames
        })
        
    except Exception as e:
        logger.error(f"Error in process_files: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 500
    


@app.route('/process', methods=['POST'])
def process_files():
    """Process multiple files (images and videos)."""
    try:
        # Check if files were uploaded
        if 'files[]' not in request.files:
            return jsonify({'error': 'No files uploaded'}), 400
            
        files = request.files.getlist('files[]')
        background_image = request.files.get('background_image')
        background_video = request.files.get('background_video')
        background_color = request.form.get('background_color', None)

        # Reset tracking lists
        global processed_images, extracted_frames, background_frames
        processed_images = []
        extracted_frames = []
        background_frames = []

        # Ensure model is loaded
        if modnet_model is None:
            success = load_modnet_model()
            if not success:
                return jsonify({'error': 'Failed to load image processing model'}), 500

        # Process background image (if provided)
        if background_image and background_image.filename and allowed_file(background_image.filename):
            bg_filename = secure_filename(background_image.filename)
            bg_path = os.path.join(app.config['BACKGROUND_FRAMES_FOLDER'], bg_filename)
            os.makedirs(os.path.dirname(bg_path), exist_ok=True)
            background_image.save(bg_path)
            background_frames.append(bg_filename)
            logger.info(f"Background image saved: {bg_filename}")

        # Process background video (if provided)
        if background_video and background_video.filename and allowed_file(background_video.filename):
            bg_video_filename = secure_filename(background_video.filename)
            bg_video_path = os.path.join(app.config['VIDEOS_FOLDER'], bg_video_filename)
            os.makedirs(os.path.dirname(bg_video_path), exist_ok=True)
            background_video.save(bg_video_path)
            bg_frames = extract_frames_from_video(bg_video_path, app.config['BACKGROUND_FRAMES_FOLDER'])
            background_frames.extend(bg_frames)
            logger.info(f"Background video processed: {bg_video_filename}, extracted {len(bg_frames)} frames")

        # Set default background color if not specified and no background frames
        if not background_frames and (background_color is None or background_color == ''):
            background_color = 'transparent'
            logger.info("Using default transparent background")
        else:
            logger.info(f"Using background color: {background_color}")

        # Check if we have any files to process
        if len(files) == 0:
            return jsonify({'error': 'No valid files provided'}), 400

        # Process each uploaded file
        for file in files:
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                file.save(file_path)
                logger.info(f"Processing file: {filename}")

                file_ext = filename.rsplit('.', 1)[1].lower()

                # Process images
                if file_ext in {'png', 'jpg', 'jpeg', 'gif'}:
                    processed_filename = f"processed_{filename.rsplit('.', 1)[0]}.png"
                    processed_file_path = os.path.join(app.config['PROCESSED_FOLDER'], processed_filename)

                    # Debug information
                    logger.info(f"Background frames: {background_frames}")
                    logger.info(f"Background color: {background_color}")
                    
                    # Apply MODNet for background removal
                    success = remove_background_modnet(
                        file_path, 
                        processed_file_path, 
                        background_frames, 
                        background_color
                    )
                    
                    if success:
                        processed_images.append(processed_filename)
                        logger.info(f"Successfully processed image: {processed_filename}")
                    else:
                        logger.error(f"Failed to process image: {filename}")
                        return jsonify({'error': f'Failed to process image: {filename}'}), 500

                # Process videos
                elif file_ext in {'mp4', 'avi', 'mov'}:
                    # Extract frames from video
                    frame_list = extract_frames_from_video(file_path, app.config['FRAMES_FOLDER'])
                    extracted_frames.extend(frame_list)
                    
                    if not frame_list:
                        return jsonify({'error': f'Failed to extract frames from video: {filename}'}), 500
                    
                    # Process each frame
                    processed_frames = remove_background_from_frames(frame_list, background_frames, background_color)
                    
                    if not processed_frames:
                        return jsonify({'error': f'Failed to process video frames: {filename}'}), 500
                    
                    # Create processed video
                    processed_video_filename = f"processed_{filename.rsplit('.', 1)[0]}.mp4"
                    processed_video_path = os.path.join(app.config['VIDEOS_FOLDER'], processed_video_filename)
                    
                    success = create_video_from_frames(processed_frames, processed_video_path)
                    if success:
                        video_url = f"/static/videos/{processed_video_filename}"
                        return jsonify({
                            'message': 'Video processed successfully',
                            'processed_images': processed_images,
                            'processed_video': video_url
                        })
                    else:
                        return jsonify({'error': f'Failed to create processed video: {filename}'}), 500

        # Return processed image URLs
        image_urls = [f"/static/processed/{img}" for img in processed_images]
        return jsonify({
            'message': 'Files processed successfully',
            'processed_images': image_urls,
            'extracted_frames': extracted_frames
        })
        
    except Exception as e:
        logger.error(f"Error in process_files: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return jsonify({'error': str(e)}), 500
    
@app.route('/api/clear_temp_files', methods=['POST'])
def clear_temp_files():
    """Clear temporary files to free up disk space."""
    folders_to_clear = ['videos', 'uploads', 'processed', 'frames', 'background_frames']
    
    try:
        for folder in folders_to_clear:
            folder_path = os.path.join(app.root_path, 'static', folder)
            if os.path.exists(folder_path):
                for filename in os.listdir(folder_path):
                    file_path = os.path.join(folder_path, filename)
                    try:
                        if os.path.isfile(file_path) or os.path.islink(file_path):
                            os.unlink(file_path)
                        elif os.path.isdir(file_path):
                            shutil.rmtree(file_path)
                    except Exception as e:
                        logger.error(f'Failed to delete {file_path}. Reason: {e}')

        return jsonify({"message": "All temporary files cleared successfully"}), 200
    except Exception as e:
        logger.error(f"Error clearing temp files: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/static/<path:path>')
def send_static(path):
    """Serve static files."""
    return send_from_directory('static', path)

@app.route('/download/<filename>')
def download(filename):
    """Download a specific file."""
    file_path = os.path.join(app.config['PROCESSED_ZIP_FOLDER'], filename)
    if not os.path.exists(file_path):
        return jsonify({'error': 'File not found'}), 404
    return send_from_directory(app.config['PROCESSED_ZIP_FOLDER'], filename, as_attachment=True)


@app.route('/download_all')
def download_all():
    """Download all processed files as a ZIP archive."""
    try:
        zip_filename = f"processed_files_{uuid.uuid4()}.zip"
        zip_filepath = os.path.join(app.config['PROCESSED_ZIP_FOLDER'], zip_filename)
        
        os.makedirs(os.path.dirname(zip_filepath), exist_ok=True)

        with zipfile.ZipFile(zip_filepath, 'w') as zip_file:
            # Add processed images
            for processed_image in processed_images:
                image_path = os.path.join(app.config['PROCESSED_FOLDER'], processed_image)
                if os.path.exists(image_path):
                    zip_file.write(image_path, os.path.basename(image_path))
            
            # Add extracted frames
            for frame in extracted_frames:
                frame_path = os.path.join(app.config['FRAMES_FOLDER'], frame)
                if os.path.exists(frame_path):
                    zip_file.write(frame_path, os.path.basename(frame_path))
        
        return send_from_directory(app.config['PROCESSED_ZIP_FOLDER'], zip_filename, as_attachment=True)
    except Exception as e:
        logger.error(f"Error in download_all: {str(e)}")
        return jsonify({"error": str(e)}), 500

# Authentication APIs
@app.route('/register', methods=['POST'])
def register():
    """Register a new user."""
    data = request.get_json()
    fullname = data.get('fullname')
    email = data.get('email')
    password = data.get('password')

    if not fullname or not email or not password:
        return jsonify({'message': 'Missing fields'}), 400

    hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
    
    new_user = User(fullname=fullname, email=email, password=hashed_password)

    try:
        db.session.add(new_user)
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return jsonify({'message': 'Email already registered'}), 400

    return jsonify({'message': 'User created successfully'}), 201

@app.route('/login', methods=['POST'])
def login():
    """User login API."""
    email = request.json.get('email', None)
    password = request.json.get('password', None)

    if not email or not password:
        return jsonify({'message': 'Email and password are required'}), 400

    user = User.query.filter_by(email=email).first()

    if user and user.check_password(password):
        user_data = {
            'fullname': user.fullname,
            'email': user.email,
            'role': user.role,
        }
        access_token = create_access_token(identity=user_data)
        response_data = {
            'access_token': access_token,
            'user': user_data,
        }
        return jsonify(response_data), 200

    return jsonify({'message': 'Invalid credentials'}), 401

# Initialize the app
CORS(app, resources={r"/*": {"origins": "*"}})


# Add a main block to run the app
if __name__ == '__main__':
    # Create necessary directories
    for folder in ['UPLOAD_FOLDER', 'PROCESSED_FOLDER', 'FRAMES_FOLDER', 
                  'VIDEOS_FOLDER', 'BACKGROUND_FRAMES_FOLDER']:
        os.makedirs(app.config[folder], exist_ok=True)
    
    # Load model at startup
    load_modnet_model()
    # Run the application
    app.run(host='0.0.0.0', port=5000, debug=True)